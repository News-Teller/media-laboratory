"use strict";
(self["webpackChunkjupyterlab_medialab"] = self["webpackChunkjupyterlab_medialab"] || []).push([["lib_index_js"],{

/***/ "./lib/AddCronjob.js":
/*!***************************!*\
  !*** ./lib/AddCronjob.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddCronjob": () => (/* binding */ AddCronjob)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var cronstrue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! cronstrue */ "webpack/sharing/consume/default/cronstrue/cronstrue");
/* harmony import */ var cronstrue__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(cronstrue__WEBPACK_IMPORTED_MODULE_1__);


const MESSSAGE_SPAN_CLASS = 'jp-Dialog-message';
const INVALID_CLASS = 'is-invalid';
class AddCronjob extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Widget {
    constructor() {
        super();
        this.addClass('jp-Input-Dialog');
        // Create input element
        this._input = document.createElement('input');
        this._input.classList.add('jp-mod-styled');
        this._input.placeholder = 'Write your cron expression here';
        this._input.id = 'jp-dialog-input-id';
        // Create label element
        const labelElement = document.createElement('label');
        labelElement.textContent = 'Cron schedule expression';
        labelElement.htmlFor = this._input.id;
        // Create span element for error display
        this._messageSpan = document.createElement('span');
        this._messageSpan.classList.add(MESSSAGE_SPAN_CLASS);
        // Add elements to the DOM
        this.node.appendChild(labelElement);
        this.node.appendChild(this._input);
        this.node.appendChild(this._messageSpan);
    }
    handleEvent(event) {
        this._evtChange(event);
    }
    onAfterAttach(msg) {
        super.onAfterAttach(msg);
        this.update();
        this._input.addEventListener('change', this);
    }
    onBeforeDetach(msg) {
        super.onBeforeDetach(msg);
        this._input.addEventListener('change', this);
    }
    getValue() {
        return this._input.value;
    }
    _evtChange(event) {
        const value = this._input.value;
        let humanFormat = undefined;
        try {
            humanFormat = cronstrue__WEBPACK_IMPORTED_MODULE_1___default().toString(value);
        }
        catch (error) {
            console.warn('Failed to parse cron expression: ', error);
        }
        if (humanFormat !== undefined) {
            // Cron expression is correct: display human-readable translation
            // and remove error message
            this._messageSpan.textContent = `Translates to: ${humanFormat}`;
            this._input.classList.remove(INVALID_CLASS);
            this._messageSpan.classList.remove(INVALID_CLASS);
        }
        else {
            // Cron expression is wrong, display an error message
            this._input.classList.add(INVALID_CLASS);
            this._messageSpan.classList.add(INVALID_CLASS);
            this._messageSpan.textContent = 'Invalid chron syntax!';
        }
    }
}


/***/ }),

/***/ "./lib/Panel.js":
/*!**********************!*\
  !*** ./lib/Panel.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MediaLabPanel": () => (/* binding */ MediaLabPanel)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");
/* harmony import */ var _ViewLog__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ViewLog */ "./lib/ViewLog.js");





const VizSection = (data, onDelete) => {
    if (data.length === 0) {
        return react__WEBPACK_IMPORTED_MODULE_2___default().createElement((react__WEBPACK_IMPORTED_MODULE_2___default().Fragment), null);
    }
    return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("table", { className: "jp-MediaLabPanel-table" },
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement("thead", null,
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement("tr", null,
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("th", null, "UID"),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("th", null, "Title"),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("th", null, "Tags"),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("th", null, "Date created"),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("th", null, "Last modified"),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("th", null, "Locked"),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("th", null, "Delete"))),
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement("tbody", null, data.map(item => (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("tr", { key: item.uid },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement("td", null, item.uid),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement("td", null, item.title),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement("td", null,
                item.tags.length === 0 && react__WEBPACK_IMPORTED_MODULE_2___default().createElement("i", null, "No tags"),
                item.tags.length > 0 && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("ul", null, item.tags.map(tag => (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("li", null, tag)))))),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement("td", null, item.createdAt),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement("td", null, item.updatedAt),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement("td", null, item.locked ? 'Yes' : 'No'),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement("td", null,
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ToolbarButtonComponent, { key: `viz-close-${item.uid}`, icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.closeIcon, tooltip: `Delete visualization "${item.uid}"`, onClick: () => onDelete(item.uid) }))))))));
};
const getCronID = (item) => {
    return item.command.replace(' ', '-');
};
const CronSection = (data, onDelete, onShellView) => {
    if (data.length === 0) {
        return react__WEBPACK_IMPORTED_MODULE_2___default().createElement((react__WEBPACK_IMPORTED_MODULE_2___default().Fragment), null);
    }
    return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("table", { className: "jp-MediaLabPanel-table" },
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement("thead", null,
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement("tr", null,
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("th", null, "Schedule"),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("th", null, "Script"),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("th", null, "Command"),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("th", null, "Log location"),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("th", null, "Log"),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("th", null, "Delete"))),
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement("tbody", null, data.map(item => {
            const id = getCronID(item);
            return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("tr", { key: `cron-${id}` },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("td", null, item.schedule),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("td", null, item.script),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("td", null, item.command),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("td", null, item.log_file),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("td", null,
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ToolbarButtonComponent, { key: `cron-view-${id}`, label: "View", tooltip: `View logs for "${item.script}"`, onClick: () => onShellView(item) })),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("td", null,
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ToolbarButtonComponent, { key: `cron-close-${id}`, icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.closeIcon, tooltip: `Remove schedule for "${item.script}"`, onClick: () => onDelete(item) }))));
        }))));
};
/**
 * React component for the main Panel.
 *
 * @returns The React component
 */
const Panel = (props) => {
    // Persist table data
    const [vizData, setVizData] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [cronData, setCronData] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(true);
    const fetchData = async (choice) => {
        let resp;
        setIsLoading(true);
        try {
            if (choice === 'viz') {
                resp = await (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('viz/get_my_visualizations');
                setVizData(resp.data || []);
            }
            else {
                resp = await (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('scheduler/list');
                setCronData(resp.data || []);
            }
        }
        catch (error) {
            console.warn(`Error while requesting data : ${error}`);
        }
        setIsLoading(false);
    };
    const onVizDelete = async (uid) => {
        const data = { uid };
        try {
            await (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('viz/delete', {
                body: JSON.stringify(data),
                method: 'POST'
            });
            // Remove deleted item from state data
            setVizData(prevState => prevState.filter(item => item.uid !== uid));
        }
        catch (error) {
            console.warn(`Error while deleting visualization "${uid}" : ${error}`);
        }
    };
    const onCronDelete = async (item) => {
        const dataToSend = {
            command: item.command,
            schedule: item.schedule
        };
        try {
            await (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('scheduler/delete', {
                body: JSON.stringify(dataToSend),
                method: 'POST'
            });
            // Remove deleted item from state data
            setCronData(prevState => prevState.filter(elem => getCronID(elem) !== getCronID(item)));
        }
        catch (error) {
            console.warn(`Error while deleting cronjob "${item.script}" : ${error}`);
        }
    };
    const onShellView = async (item) => {
        const { shell } = props;
        // Create widget for displaying log file & attach to shell (app.shell)
        (0,_ViewLog__WEBPACK_IMPORTED_MODULE_4__.openViewLogWidget)(shell, item.schedule, item.command);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
        fetchData('viz');
        fetchData('scheduler');
    }, []);
    const sections = [
        {
            title: 'All visualizations',
            content: VizSection(vizData, onVizDelete),
            onRefresh: () => fetchData('viz')
        },
        {
            title: 'Scheduled visualizations',
            content: CronSection(cronData, onCronDelete, onShellView),
            onRefresh: () => fetchData('scheduler')
        }
    ];
    return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", { className: "jp-Launcher-body" },
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", { className: "jp-Launcher-content" },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", { className: `jp-extensionmanager-pending ${isLoading ? 'jp-mod-hasPending' : ''}` }),
            sections.map((section, index) => (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", { className: "jp-Launcher-section", key: `section-${index}` },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", { className: "jp-Launcher-sectionHeader" },
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement("h2", { className: "jp-Launcher-sectionTitle" }, section.title),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ToolbarButtonComponent, { icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.refreshIcon, tooltip: "Refresh list", onClick: section.onRefresh })),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", { className: "jp-Launcher-cardContainer" }, section.content)))))));
};
/**
 * A Lumino Widget that wraps a Panel.
 */
class MediaLabPanel extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    /**
     * Constructs a new ShowWidget.
     */
    constructor(shell) {
        super();
        this.addClass('jp-MediaLabPanel');
        this.id = 'medialab-visualizations';
        this.title.label = 'MediaLab visualizations';
        this.title.closable = true;
        this._shell = shell;
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_2___default().createElement(Panel, { shell: this._shell });
    }
}


/***/ }),

/***/ "./lib/ViewLog.js":
/*!************************!*\
  !*** ./lib/ViewLog.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "openViewLogWidget": () => (/* binding */ openViewLogWidget)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");



/**
 * React component for ViewLog
 *
 * @returns The React component
 */
const Logs = (props) => {
    const [state, setState] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        logs: undefined
    });
    const getLogs = async (schedule, command) => {
        let resp;
        try {
            resp = await (0,_handler__WEBPACK_IMPORTED_MODULE_2__.requestAPI)(`scheduler/log?command=${command}&schedule=${schedule}`);
        }
        catch (error) {
            console.warn(`Error while fetching log for '${command}' : ${error}`);
        }
        if (resp && resp.success && resp.data) {
            setState({ logs: resp.data.reverse().join('\n') });
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        getLogs(props.schedule, props.command);
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "CodeMirror-scroll" },
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "jp-MediaLabLog-sizer" },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("pre", null, state.logs))));
};
/**
 * A Lumino Widget that wraps a ViewLog component.
 */
class ViewLogWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    /**
     * Constructs a new ShowWidget.
     */
    constructor(command, schedule) {
        super();
        this._command = command;
        this._schedule = schedule;
        this.addClass('jp-MediaLabLog');
        this.title.label = `Log - ${command}`;
        this.title.closable = true;
        this.id = 'medialab-job-log';
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_1___default().createElement(Logs, { command: this._command, schedule: this._schedule });
    }
}
const openViewLogWidget = (shell, schedule, command) => {
    // Create widget for displaying jobs & attach
    const content = new ViewLogWidget(command, schedule);
    const widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.MainAreaWidget({ content });
    shell.add(widget, 'main');
};


/***/ }),

/***/ "./lib/handler.js":
/*!************************!*\
  !*** ./lib/handler.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "requestAPI": () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'jupyterlab-medialab', // API Namespace
    endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.warn('Not a JSON response body: ', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message || data);
    }
    return data;
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/mainmenu */ "webpack/sharing/consume/default/@jupyterlab/mainmenu");
/* harmony import */ var _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _Panel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Panel */ "./lib/Panel.js");
/* harmony import */ var _AddCronjob__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./AddCronjob */ "./lib/AddCronjob.js");
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");









/**
 * The command IDs used by the react-widget plugin.
 */
var CommandIDs;
(function (CommandIDs) {
    CommandIDs.show = 'show-viz';
    CommandIDs.addCron = 'jupyterlab_medialab/add-cron:open';
})(CommandIDs || (CommandIDs = {}));
/**
 * Initialization data for the jupyterlab_medialab extension.
 */
const plugin = {
    id: 'jupyterlab_medialab:plugin',
    autoStart: true,
    requires: [
        _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.JupyterFrontEnd.IPaths,
        _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__.IFileBrowserFactory,
        _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__.ICommandPalette,
        _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_2__.IMainMenu
    ],
    activate: (app, paths, factory, palette, mainMenu) => {
        const { commands, shell } = app;
        // Add command to list all visualizations
        commands.addCommand(CommandIDs.show, {
            label: 'List all visualizations',
            caption: 'List all MediaLab visualizations',
            execute: (args) => {
                const content = new _Panel__WEBPACK_IMPORTED_MODULE_6__.MediaLabPanel(shell);
                const widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__.MainAreaWidget({ content });
                shell.add(widget, 'main');
            }
        });
        // Add a command to schedule a cronjob
        commands.addCommand(CommandIDs.addCron, {
            label: 'Schedule visualization',
            caption: 'Schedule recurring execution for visualizations',
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_5__.runIcon,
            execute: async (args) => {
                // Create dialog for scheduling jobs
                const file = factory.tracker.currentWidget
                    ? factory.tracker.currentWidget.selectedItems().next()
                    : null;
                if (!file) {
                    console.warn(`Executed command ${CommandIDs.addCron} with null file.`);
                    return;
                }
                const fullPath = paths.directories.serverRoot.concat('/', file.path);
                const result = await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__.showDialog)({
                    title: `Schedule recurring execution for: ${file.name}`,
                    body: new _AddCronjob__WEBPACK_IMPORTED_MODULE_7__.AddCronjob(),
                    buttons: [
                        _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__.Dialog.cancelButton(),
                        _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__.Dialog.okButton({ label: 'Schedule' })
                    ],
                    focusNodeSelector: 'input'
                });
                if (!result.button.accept) {
                    return;
                }
                const dataToSend = {
                    schedule: result.value,
                    script: file.name,
                    command: `papermill ${fullPath} /dev/null`
                };
                // Call scheduler API
                try {
                    await (0,_handler__WEBPACK_IMPORTED_MODULE_8__.requestAPI)('scheduler/add', {
                        body: JSON.stringify(dataToSend),
                        method: 'POST'
                    });
                }
                catch (error) {
                    console.warn(`Error while scheduling recurring executing for '${file.name}': ${error}`);
                    (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__.showErrorMessage)('An error occured', error);
                }
            }
        });
        // Add previous command to the context menu
        app.contextMenu.addItem({
            command: CommandIDs.addCron,
            selector: '.jp-DirListing-item[data-file-type="notebook"]'
            // rank: 0
        });
        // Add the command to the command palette
        const category = 'Extension Examples';
        palette.addItem({
            command: CommandIDs.show,
            category,
            args: { origin: 'from the palette' }
        });
        palette.addItem({
            command: CommandIDs.addCron,
            category,
            args: { origin: 'from the palette' }
        });
        // Create a menu
        const datavizMenu = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_3__.Menu({ commands });
        datavizMenu.title.label = 'MediaLab';
        mainMenu.addMenu(datavizMenu, { rank: 80 });
        // Add commands to the menu
        datavizMenu.addItem({ command: CommandIDs.show, args: { origin: 'menu' } });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.313752223c9866562aed.js.map